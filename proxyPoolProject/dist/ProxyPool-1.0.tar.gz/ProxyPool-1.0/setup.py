# -*- coding:utf-8 _*-
"""
@version:
author:weichao_an
@time: 2020/10/13
@file: setup.py.py
@environment:virtualenv
@email:awc19930818@outlook.com
@github:https://github.com/La0bALanG
@requirement:
"""


from distutils.core import setup

setup(name='ProxyPool',version='1.0',author='Barranzi',py_modules=['ProxyPool.proxyPool'])
